<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Showcase extends Model
{
    protected $table = 'showcases';

    protected $fillable = [
        'seller_id',
        'type',

        // legacy
        'title',
        'subtitle',
        'intro',
        'description',

        // bilingual
        'title_gr',
        'title_en',
        'subtitle_gr',
        'subtitle_en',
        'intro_gr',
        'intro_en',
        'description_gr',
        'description_en',

        'cover_image',
        'main_visual',
        'linked_products',
        'billing_period',
        'status',
    ];
}