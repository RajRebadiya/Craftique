<?php

namespace App\Http\Controllers\Seller\Concerns;

use Illuminate\Support\Facades\DB;

trait EnforcesShowcasePackageLimits
{
    protected function ensureShowcaseCreationAllowed()
    {
        $shop = $this->shop();
        $limit = optional($shop->seller_package)->showcase_post_limit;

        if ($limit === '' || $limit === null) {
            return null;
        }

        $limit = (int) $limit;

        $currentCount = DB::table('showcases')
            ->where('seller_id', $shop->id)
            ->count();

        if ($currentCount >= $limit) {
            flash(translate('Your package showcase post limit has been reached.'))->warning();
            return redirect()->route('seller.showcase.index');
        }

        return null;
    }
}