<?php

namespace App\Http\Controllers\Seller;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Seller\Concerns\EnforcesShowcasePackageLimits;
use App\Models\Showcase;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ShowcaseHistoryController extends Controller
{
    use EnforcesShowcasePackageLimits;

    public function index()
    {
        $redirect = $this->ensureActivePackage();
        if ($redirect) {
            return $redirect;
        }

        $shop = $this->shop();

        $items = Showcase::where('seller_id', $shop->id)
            ->where('type', 'history')
            ->latest()
            ->paginate(15);

        return view('seller.showcase.history.index', [
            'shop'  => $shop,
            'items' => $items,
        ]);
    }

    public function create()
    {
        $redirect = $this->ensureActivePackage();
        if ($redirect) {
            return $redirect;
        }

        $limitRedirect = $this->ensureShowcaseCreationAllowed();
        if ($limitRedirect) {
            return $limitRedirect;
        }

        return $this->renderForm('Create Story');
    }

    public function edit($id)
    {
        $redirect = $this->ensureActivePackage();
        if ($redirect) {
            return $redirect;
        }

        $item = $this->sellerHistoryItem($id);

        return $this->renderForm('Edit Story', $item);
    }

    public function store(Request $request)
    {
        $redirect = $this->ensureActivePackage();
        if ($redirect) {
            return $redirect;
        }

        $limitRedirect = $this->ensureShowcaseCreationAllowed();
        if ($limitRedirect) {
            return $limitRedirect;
        }

        $shop = $this->shop();

        $titleGr = $request->input('title_gr', $request->input('title'));
        $titleEn = $request->input('title_en');

        $subtitleGr = $request->input('subtitle_gr', $request->input('subtitle'));
        $subtitleEn = $request->input('subtitle_en');

        $descriptionGr = $request->input('description_gr', $request->input('description'));
        $descriptionEn = $request->input('description_en');

        $validated = $request->validate([
            'story_video'   => 'nullable',
            'cover_image'   => 'nullable',
            'status'        => 'required|in:draft,published',
            'product_ids'   => 'nullable|array',
            'product_ids.*' => 'integer',
        ]);

        if (!$titleGr && !$titleEn) {
            return back()
                ->withInput()
                ->withErrors([
                    'title_gr' => translate('Please enter at least one title in Greek or English.')
                ]);
        }

        if (empty($validated['story_video'])) {
            return back()
                ->withInput()
                ->withErrors([
                    'story_video' => translate('Please upload a Story video.')
                ]);
        }

        $saveData = [
            'seller_id'       => $shop->id,
            'type'            => 'history',
            'title'           => $titleGr ?: $titleEn,
            'subtitle'        => $subtitleGr ?: $subtitleEn,
            'description'     => $descriptionGr ?: $descriptionEn,
            'title_gr'        => $titleGr,
            'title_en'        => $titleEn,
            'subtitle_gr'     => $subtitleGr,
            'subtitle_en'     => $subtitleEn,
            'description_gr'  => $descriptionGr,
            'description_en'  => $descriptionEn,
            'main_visual'     => $validated['story_video'],
            'cover_image'     => $request->input('cover_image'),
            'status'          => $validated['status'],
        ];

        $item = Showcase::create($saveData);

        $this->syncProducts($item->id, $request->input('product_ids', []));

        flash(translate('Story saved successfully'))->success();
        return redirect()->route('seller.showcase.history.index');
    }

    public function update(Request $request, $id)
    {
        $redirect = $this->ensureActivePackage();
        if ($redirect) {
            return $redirect;
        }

        $item = $this->sellerHistoryItem($id);

        $titleGr = $request->input('title_gr', $request->input('title'));
        $titleEn = $request->input('title_en');

        $subtitleGr = $request->input('subtitle_gr', $request->input('subtitle'));
        $subtitleEn = $request->input('subtitle_en');

        $descriptionGr = $request->input('description_gr', $request->input('description'));
        $descriptionEn = $request->input('description_en');

        $validated = $request->validate([
            'story_video'   => 'nullable',
            'cover_image'   => 'nullable',
            'status'        => 'required|in:draft,published',
            'product_ids'   => 'nullable|array',
            'product_ids.*' => 'integer',
        ]);

        if (!$titleGr && !$titleEn) {
            return back()
                ->withInput()
                ->withErrors([
                    'title_gr' => translate('Please enter at least one title in Greek or English.')
                ]);
        }

        $storyVideo = $validated['story_video'] ?? $item->main_visual;

        if (empty($storyVideo)) {
            return back()
                ->withInput()
                ->withErrors([
                    'story_video' => translate('Please upload a Story video.')
                ]);
        }

        $item->update([
            'title'           => $titleGr ?: $titleEn,
            'subtitle'        => $subtitleGr ?: $subtitleEn,
            'description'     => $descriptionGr ?: $descriptionEn,
            'title_gr'        => $titleGr,
            'title_en'        => $titleEn,
            'subtitle_gr'     => $subtitleGr,
            'subtitle_en'     => $subtitleEn,
            'description_gr'  => $descriptionGr,
            'description_en'  => $descriptionEn,
            'main_visual'     => $storyVideo,
            'cover_image'     => $request->input('cover_image'),
            'status'          => $validated['status'],
        ]);

        $this->syncProducts($item->id, $request->input('product_ids', []));

        flash(translate('Story updated successfully'))->success();
        return redirect()->route('seller.showcase.history.index');
    }

    public function toggleStatus($id)
    {
        $redirect = $this->ensureActivePackage();
        if ($redirect) {
            return $redirect;
        }

        $item = $this->sellerHistoryItem($id);

        $item->status = $item->status === 'published' ? 'draft' : 'published';
        $item->save();

        flash(translate('Story status updated successfully'))->success();
        return redirect()->route('seller.showcase.history.index');
    }

    public function destroy($id)
    {
        $redirect = $this->ensureActivePackage();
        if ($redirect) {
            return $redirect;
        }

        $item = $this->sellerHistoryItem($id);

        DB::table('showcase_products')->where('showcase_id', $item->id)->delete();
        $item->delete();

        flash(translate('Story deleted successfully'))->success();
        return redirect()->route('seller.showcase.history.index');
    }

    private function renderForm($pageTitle, $item = null)
    {
        $shop = $this->shop();

        $products = DB::table('products')
            ->where('user_id', auth()->id())
            ->select('id', 'name')
            ->orderByDesc('id')
            ->limit(200)
            ->get();

        $selectedProducts = [];
        if ($item) {
            $selectedProducts = DB::table('showcase_products')
                ->where('showcase_id', $item->id)
                ->orderBy('sort_order')
                ->pluck('product_id')
                ->toArray();
        }

        return view('seller.showcase.history.form', [
            'shop'             => $shop,
            'page_title'       => $pageTitle,
            'item'             => $item,
            'products'         => $products,
            'selectedProducts' => $selectedProducts,
        ]);
    }

    private function sellerHistoryItem($id): Showcase
    {
        return Showcase::where('id', $id)
            ->where('type', 'history')
            ->where('seller_id', $this->shop()->id)
            ->firstOrFail();
    }

    private function syncProducts($showcaseId, array $productIds = [])
    {
        $allowedProductIds = DB::table('products')
            ->where('user_id', auth()->id())
            ->whereIn('id', $productIds)
            ->pluck('id')
            ->map(fn ($id) => (int) $id)
            ->toArray();

        DB::table('showcase_products')->where('showcase_id', $showcaseId)->delete();

        $rows = [];
        foreach ($allowedProductIds as $index => $productId) {
            $rows[] = [
                'showcase_id' => $showcaseId,
                'product_id'  => $productId,
                'sort_order'  => $index,
                'created_at'  => now(),
                'updated_at'  => now(),
            ];
        }

        if (!empty($rows)) {
            DB::table('showcase_products')->insert($rows);
        }
    }

    private function ensureActivePackage()
    {
        $shop = $this->shop();

        $hasActivePackage = !empty($shop->seller_package_id);

        if ($hasActivePackage && !empty($shop->package_invalid_at)) {
            $hasActivePackage = Carbon::parse($shop->package_invalid_at)->endOfDay()->gte(now());
        }

        if (!$hasActivePackage) {
            flash(translate('You need an active seller package to use Showcase.'))->warning();
            return redirect()->route('seller.showcase.index');
        }

        return null;
    }

    private function shop()
    {
        $shop = auth()->user()->shop;
        abort_unless($shop, 404);

        return $shop;
    }
}