<?php

namespace App\Http\Controllers\Seller;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Seller\Concerns\EnforcesShowcasePackageLimits;
use App\Models\Showcase;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ShowcaseCollectionController extends Controller
{
    use EnforcesShowcasePackageLimits;

    public function index()
    {
        $redirect = $this->ensureActivePackage();
        if ($redirect) {
            return $redirect;
        }

        $shop = $this->shop();

        $items = Showcase::where('seller_id', $shop->id)
            ->where('type', 'collection')
            ->latest()
            ->paginate(15);

        return view('seller.showcase.collection.index', [
            'shop'  => $shop,
            'items' => $items,
        ]);
    }

    public function create()
    {
        $redirect = $this->ensureActivePackage();
        if ($redirect) {
            return $redirect;
        }

        $limitRedirect = $this->ensureShowcaseCreationAllowed();
        if ($limitRedirect) {
            return $limitRedirect;
        }

        return $this->renderForm('Create Collection');
    }

    public function edit($id)
    {
        $redirect = $this->ensureActivePackage();
        if ($redirect) {
            return $redirect;
        }

        $item = $this->sellerCollectionItem($id);

        return $this->renderForm('Edit Collection', $item);
    }

    public function store(Request $request)
    {
        $redirect = $this->ensureActivePackage();
        if ($redirect) {
            return $redirect;
        }

        $limitRedirect = $this->ensureShowcaseCreationAllowed();
        if ($limitRedirect) {
            return $limitRedirect;
        }

        $shop = $this->shop();

        $titleGr = $request->input('title_gr', $request->input('title'));
        $titleEn = $request->input('title_en');

        $introGr = $request->input('intro_gr', $request->input('intro'));
        $introEn = $request->input('intro_en');

        $descriptionGr = $request->input('description_gr', $request->input('description'));
        $descriptionEn = $request->input('description_en');

        $validated = $request->validate([
            'cover_image'     => 'nullable',
            'billing_period'  => 'nullable|in:monthly,yearly',
            'status'          => 'required|in:draft,published',
            'product_ids'     => 'nullable|array',
            'product_ids.*'   => 'integer',
        ]);

        if (!$titleGr && !$titleEn) {
            return back()
                ->withInput()
                ->withErrors([
                    'title_gr' => translate('Please enter at least one title in Greek or English.')
                ]);
        }

        $saveData = [
            'seller_id'      => $shop->id,
            'type'           => 'collection',
            'title'          => $titleGr ?: $titleEn,
            'intro'          => $introGr ?: $introEn,
            'description'    => $descriptionGr ?: $descriptionEn,
            'title_gr'       => $titleGr,
            'title_en'       => $titleEn,
            'intro_gr'       => $introGr,
            'intro_en'       => $introEn,
            'description_gr' => $descriptionGr,
            'description_en' => $descriptionEn,
            'cover_image'    => $request->input('cover_image'),
            'billing_period' => $validated['billing_period'] ?? null,
            'status'         => $validated['status'],
        ];

        $item = Showcase::create($saveData);

        $this->syncProducts($item->id, $request->input('product_ids', []));

        flash(translate('Collection saved successfully'))->success();
        return redirect()->route('seller.showcase.collection.index');
    }

    public function update(Request $request, $id)
    {
        $redirect = $this->ensureActivePackage();
        if ($redirect) {
            return $redirect;
        }

        $item = $this->sellerCollectionItem($id);

        $titleGr = $request->input('title_gr', $request->input('title'));
        $titleEn = $request->input('title_en');

        $introGr = $request->input('intro_gr', $request->input('intro'));
        $introEn = $request->input('intro_en');

        $descriptionGr = $request->input('description_gr', $request->input('description'));
        $descriptionEn = $request->input('description_en');

        $validated = $request->validate([
            'cover_image'     => 'nullable',
            'billing_period'  => 'nullable|in:monthly,yearly',
            'status'          => 'required|in:draft,published',
            'product_ids'     => 'nullable|array',
            'product_ids.*'   => 'integer',
        ]);

        if (!$titleGr && !$titleEn) {
            return back()
                ->withInput()
                ->withErrors([
                    'title_gr' => translate('Please enter at least one title in Greek or English.')
                ]);
        }

        $saveData = [
            'title'          => $titleGr ?: $titleEn,
            'intro'          => $introGr ?: $introEn,
            'description'    => $descriptionGr ?: $descriptionEn,
            'title_gr'       => $titleGr,
            'title_en'       => $titleEn,
            'intro_gr'       => $introGr,
            'intro_en'       => $introEn,
            'description_gr' => $descriptionGr,
            'description_en' => $descriptionEn,
            'cover_image'    => $request->input('cover_image'),
            'billing_period' => $validated['billing_period'] ?? null,
            'status'         => $validated['status'],
        ];

        $item->update($saveData);

        $this->syncProducts($item->id, $request->input('product_ids', []));

        flash(translate('Collection updated successfully'))->success();
        return redirect()->route('seller.showcase.collection.index');
    }

    public function toggleStatus($id)
    {
        $redirect = $this->ensureActivePackage();
        if ($redirect) {
            return $redirect;
        }

        $item = $this->sellerCollectionItem($id);

        $item->status = $item->status === 'published' ? 'draft' : 'published';
        $item->save();

        flash(translate('Collection status updated successfully'))->success();
        return redirect()->route('seller.showcase.collection.index');
    }

    public function destroy($id)
    {
        $redirect = $this->ensureActivePackage();
        if ($redirect) {
            return $redirect;
        }

        $item = $this->sellerCollectionItem($id);

        DB::table('showcase_products')->where('showcase_id', $item->id)->delete();
        $item->delete();

        flash(translate('Collection deleted successfully'))->success();
        return redirect()->route('seller.showcase.collection.index');
    }

    private function renderForm($pageTitle, $item = null)
    {
        $shop = $this->shop();

        $products = DB::table('products')
            ->where('user_id', auth()->id())
            ->select('id', 'name')
            ->orderByDesc('id')
            ->limit(200)
            ->get();

        $selectedProducts = [];
        if ($item) {
            $selectedProducts = DB::table('showcase_products')
                ->where('showcase_id', $item->id)
                ->orderBy('sort_order')
                ->pluck('product_id')
                ->toArray();
        }

        return view('seller.showcase.collection.form', [
            'shop'             => $shop,
            'page_title'       => $pageTitle,
            'item'             => $item,
            'products'         => $products,
            'selectedProducts' => $selectedProducts,
        ]);
    }

    private function sellerCollectionItem($id): Showcase
    {
        return Showcase::where('id', $id)
            ->where('type', 'collection')
            ->where('seller_id', $this->shop()->id)
            ->firstOrFail();
    }

    private function syncProducts($showcaseId, array $productIds = [])
    {
        $allowedProductIds = DB::table('products')
            ->where('user_id', auth()->id())
            ->whereIn('id', $productIds)
            ->pluck('id')
            ->map(fn ($id) => (int) $id)
            ->toArray();

        DB::table('showcase_products')->where('showcase_id', $showcaseId)->delete();

        $rows = [];
        foreach ($allowedProductIds as $index => $productId) {
            $rows[] = [
                'showcase_id' => $showcaseId,
                'product_id'  => $productId,
                'sort_order'  => $index,
                'created_at'  => now(),
                'updated_at'  => now(),
            ];
        }

        if (!empty($rows)) {
            DB::table('showcase_products')->insert($rows);
        }
    }

    private function ensureActivePackage()
    {
        $shop = $this->shop();

        $hasActivePackage = !empty($shop->seller_package_id);

        if ($hasActivePackage && !empty($shop->package_invalid_at)) {
            $hasActivePackage = Carbon::parse($shop->package_invalid_at)->endOfDay()->gte(now());
        }

        if (!$hasActivePackage) {
            flash(translate('You need an active seller package to use Showcase.'))->warning();
            return redirect()->route('seller.showcase.index');
        }

        return null;
    }

    private function shop()
    {
        $shop = auth()->user()->shop;
        abort_unless($shop, 404);

        return $shop;
    }
}