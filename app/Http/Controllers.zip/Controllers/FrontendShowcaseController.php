<?php

namespace App\Http\Controllers;

use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

class FrontendShowcaseController extends Controller
{
    public function history()
    {
        return $this->renderShowcase('history', 'frontend.showcase.history');
    }

    public function collection()
    {
        return $this->renderShowcase('collection', 'frontend.showcase.collection');
    }

    public function vitrin()
    {
        return $this->renderShowcase('vitrin', 'frontend.showcase.vitrin');
    }

    public function show($id, $slug = null)
    {
        $item = DB::table('showcases')
            ->leftJoin('shops', 'showcases.seller_id', '=', 'shops.id')
            ->where('showcases.id', $id)
            ->where('showcases.status', 'published')
            ->select('showcases.*', 'shops.name as seller_name')
            ->first();

        abort_unless($item, 404);

        $item = $this->applyLocaleFields($item);

        $products = $this->getShowcaseProducts($item->id);

        return view('frontend.showcase.history', [
            'item'     => $item,
            'products' => $products,
        ]);
    }

    private function renderShowcase(string $type, string $view)
    {
        $item = DB::table('showcases')
            ->leftJoin('shops', 'showcases.seller_id', '=', 'shops.id')
            ->where('showcases.type', $type)
            ->where('showcases.status', 'published')
            ->orderByDesc('showcases.created_at')
            ->select('showcases.*', 'shops.name as seller_name')
            ->first();

        $products = collect();

        if ($item) {
            $item = $this->applyLocaleFields($item);
            $products = $this->getShowcaseProducts($item->id);
        }

        return view($view, [
            'item'     => $item,
            'products' => $products,
        ]);
    }

    private function applyLocaleFields($item)
    {
        $locale = app()->getLocale();

        $item->title = $locale === 'en'
            ? ($item->title_en ?: $item->title_gr ?: $item->title)
            : ($item->title_gr ?: $item->title_en ?: $item->title);

        $item->subtitle = $locale === 'en'
            ? (($item->subtitle_en ?? null) ?: ($item->subtitle_gr ?? null) ?: ($item->subtitle ?? null))
            : (($item->subtitle_gr ?? null) ?: ($item->subtitle_en ?? null) ?: ($item->subtitle ?? null));

        $item->intro = $locale === 'en'
            ? (($item->intro_en ?? null) ?: ($item->intro_gr ?? null) ?: ($item->intro ?? null))
            : (($item->intro_gr ?? null) ?: ($item->intro_en ?? null) ?: ($item->intro ?? null));

        $item->description = $locale === 'en'
            ? ($item->description_en ?: $item->description_gr ?: $item->description)
            : ($item->description_gr ?: $item->description_en ?: $item->description);

        return $item;
    }

    private function getShowcaseProducts($showcaseId): Collection
    {
        return DB::table('showcase_products')
            ->join('products', 'showcase_products.product_id', '=', 'products.id')
            ->where('showcase_products.showcase_id', $showcaseId)
            ->orderBy('showcase_products.sort_order')
            ->select(
                'products.id',
                'products.name',
                'products.slug',
                'products.thumbnail_img',
                'products.unit_price',
                'products.discount',
                'products.discount_type'
            )
            ->get();
    }
}