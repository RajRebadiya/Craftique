<?php

namespace App\Http\Controllers;

use App\Models\Showcase;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ShowcaseController extends Controller
{
    public function history()
    {
        return $this->renderForm('history', 'Showcase History', 'backend.showcase.history', null);
    }

    public function collection()
    {
        return $this->renderForm('collection', 'Showcase Collection', 'backend.showcase.collection', null);
    }

    public function vitrin()
    {
        return $this->renderForm('vitrin', 'Showcase Vitrin', 'backend.showcase.vitrin', null);
    }

    public function oru()
    {
        return redirect()->route('showcase.vitrin');
    }

    public function historyList()
    {
        return $this->renderList('history', 'Showcase History List');
    }

    public function collectionList()
    {
        return $this->renderList('collection', 'Showcase Collection List');
    }

    public function vitrinList()
    {
        return $this->renderList('vitrin', 'Showcase Vitrin List');
    }

    public function historyEdit($id)
    {
        $item = Showcase::where('id', $id)->where('type', 'history')->firstOrFail();

        return $this->renderForm('history', 'Edit Showcase History', 'backend.showcase.history', $item);
    }

    public function collectionEdit($id)
    {
        $item = Showcase::where('id', $id)->where('type', 'collection')->firstOrFail();

        return $this->renderForm('collection', 'Edit Showcase Collection', 'backend.showcase.collection', $item);
    }

    public function vitrinEdit($id)
    {
        $item = Showcase::where('id', $id)->where('type', 'vitrin')->firstOrFail();

        return $this->renderForm('vitrin', 'Edit Showcase Vitrin', 'backend.showcase.vitrin', $item);
    }

    public function historyDelete($id)
    {
        $item = Showcase::where('id', $id)->where('type', 'history')->firstOrFail();
        DB::table('showcase_products')->where('showcase_id', $item->id)->delete();
        $item->delete();

        return redirect()->route('showcase.history.list')->with('success', 'Showcase History deleted successfully.');
    }

    public function historyToggleStatus($id)
    {
        $item = Showcase::where('id', $id)->where('type', 'history')->firstOrFail();
        $item->status = $item->status === 'published' ? 'draft' : 'published';
        $item->save();

        return redirect()->route('showcase.history.list')->with('success', 'History status updated successfully.');
    }

    public function collectionDelete($id)
    {
        $item = Showcase::where('id', $id)->where('type', 'collection')->firstOrFail();
        DB::table('showcase_products')->where('showcase_id', $item->id)->delete();
        $item->delete();

        return redirect()->route('showcase.collection.list')->with('success', 'Showcase Collection deleted successfully.');
    }

    public function collectionToggleStatus($id)
    {
        $item = Showcase::where('id', $id)->where('type', 'collection')->firstOrFail();
        $item->status = $item->status === 'published' ? 'draft' : 'published';
        $item->save();

        return redirect()->route('showcase.collection.list')->with('success', 'Collection status updated successfully.');
    }

    public function vitrinDelete($id)
    {
        $item = Showcase::where('id', $id)->where('type', 'vitrin')->firstOrFail();
        DB::table('showcase_products')->where('showcase_id', $item->id)->delete();
        $item->delete();

        return redirect()->route('showcase.vitrin.list')->with('success', 'Showcase Vitrin deleted successfully.');
    }

    public function vitrinToggleStatus($id)
    {
        $item = Showcase::where('id', $id)->where('type', 'vitrin')->firstOrFail();
        $item->status = $item->status === 'published' ? 'draft' : 'published';
        $item->save();

        return redirect()->route('showcase.vitrin.list')->with('success', 'Vitrin status updated successfully.');
    }

    public function storeHistory(Request $request)
{
    $titleGr = $request->input('title_gr', $request->input('title'));
    $titleEn = $request->input('title_en');

    $subtitleGr = $request->input('subtitle_gr', $request->input('subtitle'));
    $subtitleEn = $request->input('subtitle_en');

    $descriptionGr = $request->input('description_gr', $request->input('description'));
    $descriptionEn = $request->input('description_en');

    $validated = $request->validate([
        'seller_id'    => 'nullable|integer',
        'cover_image'  => 'nullable',
        'status'       => 'required|in:draft,published',
        'product_ids'  => 'nullable|array',
        'product_ids.*'=> 'integer',
    ]);

    if (!$titleGr && !$titleEn) {
        return back()
            ->withInput()
            ->withErrors(['title_gr' => 'Βάλε τουλάχιστον έναν τίτλο.']);
    }

    $saveData = [
        'seller_id'       => $validated['seller_id'] ?? null,
        'type'            => 'history',

        // legacy fallback fields
        'title'           => $titleGr ?: $titleEn,
        'subtitle'        => $subtitleGr ?: $subtitleEn,
        'description'     => $descriptionGr ?: $descriptionEn,

        // bilingual fields
        'title_gr'        => $titleGr,
        'title_en'        => $titleEn,
        'subtitle_gr'     => $subtitleGr,
        'subtitle_en'     => $subtitleEn,
        'description_gr'  => $descriptionGr,
        'description_en'  => $descriptionEn,

        'cover_image'     => $request->input('cover_image'),
        'status'          => $validated['status'],
    ];

    if ($request->filled('id')) {
        $item = \App\Models\Showcase::where('id', $request->id)
            ->where('type', 'history')
            ->firstOrFail();

        $item->update($saveData);
    } else {
        $item = \App\Models\Showcase::create($saveData);
    }

    $this->syncProducts($item->id, $request->input('product_ids', []));

    return redirect()
        ->route('showcase.history.list')
        ->with('success', 'Showcase History saved successfully.');
}

    public function storeCollection(Request $request)
    {
        $data = $request->validate([
            'title'          => 'required|string|max:255',
            'intro'          => 'nullable|string',
            'cover_image'    => 'nullable|string|max:500',
            'description'    => 'nullable|string',
            'billing_period' => 'nullable|in:monthly,yearly',
            'status'         => 'required|in:draft,published',
            'product_ids'    => 'nullable|array',
            'product_ids.*'  => 'integer',
        ]);

        $saveData = [
            'type'           => 'collection',
            'title'          => $data['title'],
            'intro'          => $data['intro'] ?? null,
            'cover_image'    => $data['cover_image'] ?? null,
            'description'    => $data['description'] ?? null,
            'billing_period' => $data['billing_period'] ?? null,
            'status'         => $data['status'],
        ];

        if ($request->filled('id')) {
            $item = Showcase::where('id', $request->id)->where('type', 'collection')->firstOrFail();
            $item->update($saveData);
        } else {
            $item = Showcase::create($saveData);
        }

        $this->syncProducts($item->id, $request->product_ids ?? []);

        return redirect()->route('showcase.collection')->with('success', 'Showcase Collection saved successfully.');
    }

    public function storeVitrin(Request $request)
    {
        $data = $request->validate([
            'title'         => 'required|string|max:255',
            'main_visual'   => 'nullable|string|max:500',
            'description'   => 'nullable|string',
            'status'        => 'required|in:draft,published',
            'product_ids'   => 'nullable|array',
            'product_ids.*' => 'integer',
        ]);

        $saveData = [
            'type'        => 'vitrin',
            'title'       => $data['title'],
            'main_visual' => $data['main_visual'] ?? null,
            'description' => $data['description'] ?? null,
            'status'      => $data['status'],
        ];

        if ($request->filled('id')) {
            $item = Showcase::where('id', $request->id)->where('type', 'vitrin')->firstOrFail();
            $item->update($saveData);
        } else {
            $item = Showcase::create($saveData);
        }

        $this->syncProducts($item->id, $request->product_ids ?? []);

        return redirect()->route('showcase.vitrin')->with('success', 'Showcase Vitrin saved successfully.');
    }

    public function storeOru(Request $request)
    {
        return $this->storeVitrin($request);
    }

    private function renderForm($section, $pageTitle, $view, $item = null)
    {
        $products = DB::table('products')
            ->select('id', 'name')
            ->orderByDesc('id')
            ->limit(200)
            ->get();

        $selectedProducts = [];
        if ($item) {
            $selectedProducts = DB::table('showcase_products')
                ->where('showcase_id', $item->id)
                ->orderBy('sort_order')
                ->pluck('product_id')
                ->toArray();
        }

        return view($view, [
            'page_title'       => $pageTitle,
            'section'          => $section,
            'item'             => $item,
            'products'         => $products,
            'selectedProducts' => $selectedProducts,
        ]);
    }

    private function renderList($type, $pageTitle)
    {
        $items = Showcase::where('type', $type)->latest()->get();

        return view('backend.showcase.list', [
            'page_title' => $pageTitle,
            'section'    => $type,
            'items'      => $items,
        ]);
    }

    private function syncProducts($showcaseId, array $productIds = [])
    {
        DB::table('showcase_products')->where('showcase_id', $showcaseId)->delete();

        $rows = [];
        foreach ($productIds as $index => $productId) {
            $rows[] = [
                'showcase_id' => $showcaseId,
                'product_id'  => (int) $productId,
                'sort_order'  => $index,
                'created_at'  => now(),
                'updated_at'  => now(),
            ];
        }

        if (!empty($rows)) {
            DB::table('showcase_products')->insert($rows);
        }
    }
}