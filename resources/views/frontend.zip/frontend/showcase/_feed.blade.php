@php
    $locale = app()->getLocale();
@endphp

@if(!empty($showcaseItems) && count($showcaseItems))
<section class="mt-4 mb-5">
    <div class="container">
        <div class="mb-4">
            <h2 class="mb-1" style="font-size: 28px; font-weight: 700;">
                Showcase
            </h2>
            <p class="mb-0 text-muted">
                {{ $locale === 'en' ? 'Stories, collections and creator vitrins' : 'Ιστορίες, συλλογές και βιτρίνες δημιουργών' }}
            </p>
        </div>

        <div class="row">
            @foreach($showcaseItems as $item)
                @php
                    $imageValue = null;

                    if ($item->type === 'history' || $item->type === 'collection') {
                        $imageValue = $item->cover_image;
                    } elseif ($item->type === 'vitrin') {
                        $imageValue = $item->main_visual;
                    }

                    $imageUrl = null;
                    if (!empty($imageValue)) {
                        $imageUrl = is_numeric($imageValue) ? uploaded_asset($imageValue) : $imageValue;
                    }

                    $title = $locale === 'en'
                        ? ($item->title_en ?: $item->title_gr ?: $item->title)
                        : ($item->title_gr ?: $item->title_en ?: $item->title);

                    $subtitle = $locale === 'en'
                        ? ($item->subtitle_en ?: $item->subtitle_gr ?: $item->subtitle)
                        : ($item->subtitle_gr ?: $item->subtitle_en ?: $item->subtitle);

                    $intro = $locale === 'en'
                        ? ($item->intro_en ?: $item->intro_gr ?: $item->intro)
                        : ($item->intro_gr ?: $item->intro_en ?: $item->intro);

                    $description = $locale === 'en'
                        ? ($item->description_en ?: $item->description_gr ?: $item->description)
                        : ($item->description_gr ?: $item->description_en ?: $item->description);

                    $excerpt = $subtitle ?: ($intro ?: $description);

                    $typeLabel = 'Showcase';
                    if ($item->type === 'history') {
                        $typeLabel = $locale === 'en' ? 'Story' : 'Ιστορία';
                    } elseif ($item->type === 'collection') {
                        $typeLabel = $locale === 'en' ? 'Collection' : 'Συλλογή';
                    } elseif ($item->type === 'vitrin') {
                        $typeLabel = $locale === 'en' ? 'Vitrin' : 'Βιτρίνα';
                    }
                @endphp

                <div class="col-md-6 col-lg-4 mb-4">
                    <a href="{{ route('frontend.showcase.post', ['id' => $item->id, 'slug' => \Illuminate\Support\Str::slug($title ?: $item->title)]) }}"
                       style="text-decoration:none; color:inherit; display:block;">
                        <div class="card border-0 shadow-sm h-100" style="border-radius:16px; overflow: hidden;">
                            <div style="height: 260px; background: #f8f8f8; display:flex; align-items:center; justify-content:center;">
                                @if($imageUrl)
                                    <img src="{{ $imageUrl }}"
                                         alt="{{ $title }}"
                                         style="width:100%; height:100%; object-fit:cover;">
                                @else
                                    <div class="text-muted">No Image</div>
                                @endif
                            </div>

                            <div class="card-body">
                                <div class="mb-2">
                                    <span class="badge badge-inline badge-soft-secondary">{{ $typeLabel }}</span>
                                </div>

                                <h3 style="font-size: 18px; font-weight: 700; line-height: 1.5;" class="mb-2">
                                    {{ $title }}
                                </h3>

                                @if(!empty($excerpt))
                                    <p class="text-muted mb-0" style="font-size: 14px; line-height: 1.7;">
                                        {{ \Illuminate\Support\Str::limit(strip_tags($excerpt), 100) }}
                                    </p>
                                @endif
                            </div>
                        </div>
                    </a>
                </div>
            @endforeach
        </div>
    </div>
</section>
@endif